<?php
// Version: 2.1.0; Settings

global $settings;

// argument(s): images_url as saved in settings
$txt['theme_thumbnail_href'] = '%1$s/thumbnail.png';
$txt['theme_description'] = 'The default theme from Simple Machines.<br><br>Author: The Simple Machines Team';
/**Spirate theme config */
$txt['spirtate_theme']='Spirate Theme Config';
/**
 * teme config spirate_index
 */
$txt['spirate_index']='Home Feed';
$txt['spirate_index_desc']='Select home feed, Recent post same ?action=recent or SSI Board News';
$txt['spirate_index_recent']='Recent Post';
$txt['spirate_index_boardnews']='Board News';
$txt['spirate_news_board']='Default Board News';
$txt['spirate_news_board_desc']='Id default board news ';
/**
 * teme config color
 */
$txt['spirate_color']='Theme Color';
$txt['spirate_color_desc']='Select Default Color theme, Dark or Light';
$txt['spirate_color_dark']='dark';
$txt['spirate_color_light']='light';

/**
 * teme brand color
 */
$txt['spirate_brand_color']='brand Color';
$txt['spirate_brand_desc']='View Colors on https://colorhunt.co/palettes/'; 

/**
 * google Global site tag 
 */
$txt['spirtate_analytics']='MEASUREMENT ID';
$txt['spirtate_analytics_desc']='Global site tag (gtag.js) - Google Analytics ';

/**
 * fluid Container
 */
$txt['spirtate_fluid_container']='Fluid Container';
$txt['spirtate_fluid_container_desc']='100%  width page';
?>