<?php
// Version: 2.1.0; Settings

global $txt; 
$txt['time_ago']    = 'ago';
$txt['just_now']   = 'just now';
$txt['year']    = 'year';
$txt['month']   = 'month';
$txt['week']    = 'week';
$txt['day']     = 'day';
$txt['hour']    = 'hour';
$txt['minute']  = 'minute';
$txt['second']  = 'second';


$txt['search_in']= ' Search %s';
$txt['s_viewprofile']= 'View profile  %s';
$txt['stardiscussion']='Start a Discussion';
$txt['spiratenews']='News';
$txt['nomorepost']='No More Posts';
$txt['spiratejoin']='Join';
$txt['boardnews']='Board News';
$txt['viewboard'] = 'Explore Board';
$txt['spiritgroup'] = 'Group';
$txt['view_profile'] = 'View profile';
$txt['theme_copyright_url']='https://dhayzon.com';
$txt['theme_copyright'] = ',Theme ❤️ Spirate';
$txt['short_by']='Short by';

?>